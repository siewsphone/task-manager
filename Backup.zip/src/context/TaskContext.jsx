import { createContext, useReducer } from "react";
import { taskReducer, initialState } from "../reducer/taskReducer";

// eslint-disable-next-line react-refresh/only-export-components
export const TaskContext = createContext();

export function TaskProvider({ children }) {
  const [state, dispatch] = useReducer(taskReducer, initialState);

  const filteredTasks = state.tasks.filter((task) =>
    state.filter === "all" ? true : task.status === state.filter
  );

  const addTask = (task) => dispatch({ type: "ADD_TASK", payload: task });
  const deleteTask = (id) => dispatch({ type: "DELETE_TASK", payload: id });
  const setFilter = (filter) => dispatch({ type: "SET_FILTER", payload: filter });

  return (
    <TaskContext.Provider
      value={{
        tasks: state.tasks,
        filter: state.filter,
        filteredTasks,
        addTask,
        deleteTask,
        setFilter,
      }}
    >
      {children}
    </TaskContext.Provider>
  );
}

