import { useParams, Link } from "react-router-dom";
import { TaskContext } from "../context/TaskContext";
import { useContext } from 'react';

const statusLabels = {
  todo: "To Do",
  "in-progress": "In Progress",
  done: "Done",
};

export default function TaskDetailPage() {
  const { id } = useParams();
  const { tasks } = useContext(TaskContext);

  const task = tasks.find((t) => t.id === Number(id));

  if (!task) {
    return (
      <div className="detail-page">
        <div className="not-found">
          <div className="not-found-icon">🔍</div>
          <h2>Task not found</h2>
          <p>The task with ID <strong>#{id}</strong> does not exist or was deleted.</p>
          <Link to="/tasks" className="btn-back">← Back to tasks</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="detail-page">
      <Link to="/tasks" className="btn-back">← Back to tasks</Link>
      <div className="detail-card">
        <h2>{task.title}</h2>
        <div className="detail-badges">
          <span className={`status-badge status-${task.status}`}>
            {statusLabels[task.status]}
          </span>
          <span className={`priority-badge priority-${task.priority}`}>
            {task.priority}
          </span>
        </div>
        <p className="detail-description">{task.description}</p>
        <div className="detail-meta">
          <div className="detail-meta-item">
            <span className="detail-meta-label">Task ID</span>
            <span className="detail-meta-value">#{task.id}</span>
          </div>
          <div className="detail-meta-item">
            <span className="detail-meta-label">Status</span>
            <span className={`status-badge status-${task.status}`}>
              {statusLabels[task.status]}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
