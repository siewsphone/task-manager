import { Link } from "react-router-dom";
import { TaskContext } from "../context/TaskContext";
import { useContext } from 'react';

const priorityColors = {
  high: "priority-high",
  medium: "priority-medium",
  low: "priority-low",
};

const statusLabels = {
  todo: "To Do",
  "in-progress": "In Progress",
  done: "Done",
};

export default function TaskList() {
  const { tasks, filteredTasks, deleteTask } = useContext(TaskContext);

  return (
    <div className="task-list">
      <p className="task-count">
        Showing {filteredTasks.length} of {tasks.length} tasks
      </p>

      {filteredTasks.length === 0 ? (
        <p className="empty-state">No tasks match the current filter.</p>
      ) : (
        <div className="task-rows">
          {filteredTasks.map((task) => (
            <div key={task.id} className="task-row">
              <Link to={`/tasks/${task.id}`} className="task-link">
                <span className="task-title">{task.title}</span>
              </Link>
              <div className="task-meta">
                <span className={`status-badge status-${task.status}`}>
                  {statusLabels[task.status]}
                </span>
                <span className={`priority-badge ${priorityColors[task.priority]}`}>
                  {task.priority}
                </span>
                <button
                  className="btn-delete"
                  onClick={() => deleteTask(task.id)}
                  title="Delete task"
                >
                  ✕
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
